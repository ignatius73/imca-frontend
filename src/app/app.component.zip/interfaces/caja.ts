

export interface Caja {
    movimiento?: string,
    detalle?: string,
    importe?: number,
    saldo?:number,
    fecha?: Date,
    name?: string,
    last_name?: string

}