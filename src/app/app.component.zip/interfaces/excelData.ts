
import { Caja } from './caja'
export interface excelData{
    title?:string,
    headers?: string[],
    data?:Caja[];
   
}