export interface Remito{
    nroRemito?: number;
    nombre?: string;
    detalle?: string[];
    importe?: number[];
    total?: number;
}