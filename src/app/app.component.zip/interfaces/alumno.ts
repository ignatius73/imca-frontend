export interface Alumno {
    _id?:string;
    dni?:number;
    nombre?: string;
    apellido?: string;
    edad?: number;
    direccion?: string;
    email?:string;
    telefono?:string;
    img?: string;
    

}
