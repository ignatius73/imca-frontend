import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cabecer-caja',
  templateUrl: './cabecer-caja.component.html',
  styleUrls: ['./cabecer-caja.component.css']
})
export class CabecerCajaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
