export interface Error{
    path?:string;
    message?:string;
}